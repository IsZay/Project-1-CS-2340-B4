from django.contrib import admin

# Register your models here.




from django.contrib import admin

# from .models import Movie

# admin.site.register(Movie)
# These lines of code allow you to see the Movie's that we have available
